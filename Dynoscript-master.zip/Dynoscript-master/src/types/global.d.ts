interface EmbedField {
	name: string;
	value: string;
	inline?: boolean;
}