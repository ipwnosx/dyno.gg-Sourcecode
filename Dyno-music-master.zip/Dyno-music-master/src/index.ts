require('source-map-support').install();

export {default as Music} from './Music';
export {default as Player} from './Player';
export {default as Queue} from './Queue';
export {default as Resolver} from './Resolver';
