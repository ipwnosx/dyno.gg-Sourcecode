'use strict';

const streamService = require('./lib/StreamService');

streamService.start();